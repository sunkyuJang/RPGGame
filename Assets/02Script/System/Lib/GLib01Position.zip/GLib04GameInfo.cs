﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace GLip
{
    class GGameInfo
    {
        public enum LayerMasksList { ImmovableObj = 8, Floor = 9, Character = 11 }

    }
}